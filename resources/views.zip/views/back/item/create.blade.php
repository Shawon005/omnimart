@extends('master.back')

@section('content')

<div class="container-fluid">

<!-- Page Heading -->
<div class="card mb-4">
    <div class="card-body">
        <div class="d-sm-flex align-items-center justify-content-between">
            <h3 class="mb-0 bc-title"><b>{{ __('Create Product') }}</b> </h3>
            <a class="btn btn-primary   btn-sm" href="{{route('back.item.index')}}"><i class="fas fa-chevron-left"></i> {{ __('Back') }}</a>
        </div>
    </div>
</div>

<!-- Form -->


<div class="row">
    <div class="col-lg-12">
            @include('alerts.alerts')
    </div>
</div>
<!-- Nested Row within Card Body -->
<form class="admin-form tab-form" action="{{ route('back.item.store') }}" method="POST"
                enctype="multipart/form-data">
                <input type="hidden" value="normal" name="item_type">
                @csrf
    <div class="row">

        <div class="col-lg-8">
            @php
                $languages = \App\Models\Language::whereType('Website')->get();
                $defaultLang = \App\Models\Language::whereType('Website')->where('is_default', 1)->first();
            @endphp
            <div class="card">
                <div class="card-body">
                    @if($languages->count() > 1)
                    <ul class="nav nav-tabs mb-3" id="nameSlugTabs" role="tablist">
                        @foreach($languages as $index => $lang)
                        <li class="nav-item">
                            <a class="nav-link {{ $index === 0 || $lang->id == $defaultLang->id ? 'active' : '' }}" 
                               id="name-lang-{{ $lang->id }}-tab" 
                               data-toggle="tab" 
                               href="#name-lang-{{ $lang->id }}" 
                               role="tab">
                                <i class="fas fa-globe"></i> {{ $lang->language }}
                                @if($lang->is_default == 1) <small>({{ __('Default') }})</small> @endif
                            </a>
                        </li>
                        @endforeach
                    </ul>
                    @endif
                    <div class="tab-content">
                        @foreach($languages as $index => $lang)
                        <div class="tab-pane fade {{ $index === 0 || $lang->id == $defaultLang->id ? 'show active' : '' }}" 
                             id="name-lang-{{ $lang->id }}" 
                             role="tabpanel">
                            <div class="form-group">
                                <label for="name_{{ $lang->id }}">{{ __('Name') }} @if($lang->is_default == 1) * @endif</label>
                                <input type="text" name="name_{{ $lang->id }}" class="form-control item-name {{ $lang->id == $defaultLang->id ? 'slug-source' : '' }}"
                                    id="name_{{ $lang->id }}" placeholder="{{ __('Enter Name') }}"
                                    value="{{ old("name_{$lang->id}") }}" >
                            </div>
                            <div class="form-group">
                                <label for="slug_{{ $lang->id }}">{{ __('Slug') }} @if($lang->is_default == 1) * @endif</label>
                                <input type="text" name="slug_{{ $lang->id }}" class="form-control slug-input"
                                    id="slug_{{ $lang->id }}" placeholder="{{ __('Enter Slug') }}"
                                    value="{{ old("slug_{$lang->id}") }}" >
                            </div>
                            @if($lang->id == $defaultLang->id)
                                <input type="hidden" name="name" class="form-control item-name" value="{{ old('name') }}">
                                <input type="hidden" name="slug" class="form-control" value="{{ old('slug') }}">
                            @endif
                        </div>
                        @endforeach
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-body">
                    <div class="form-group pb-0  mb-0">
                        <label class="d-block">{{ __('Featured Image') }} *</label>
                    </div>
                    <div class="form-group pb-0 pt-0 mt-0 mb-0">
                    <img class="admin-img lg" src="" >
                    </div>
                    <div class="form-group position-relative ">
                        <label class="file">
                            <input type="file"  accept="image/*"   class="upload-photo" name="photo"
                                id="file"  aria-label="File browser example">
                            <span
                                class="file-custom text-left">{{ __('Upload Image...') }}</span>
                        </label>
                        <br>
                        <span class="mt-1 text-info">{{ __('Image Size Should Be 800 x 800. or square size') }}</span>
                    </div>
                    <div class="form-group">
                        <label for="alt_text">{{ __('Alt Text') }}</label>
                        <input type="text" name="alt_text" class="form-control"
                            id="alt_text" placeholder="{{ __('Enter Alt Text for SEO') }}"
                            value="{{ old('alt_text') }}">
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-body">
                    <div class="form-group pb-0  mb-0">
                        <label>{{ __('Gallery Images') }} </label>
                    </div>
                    <div class="form-group pb-0 pt-0 mt-0 mb-0">
                        <div id="gallery-images" class="">
                            <div class="d-block gallery_image_view">
                            </div>
                        </div>
                    </div>
                    <div class="form-group position-relative ">
                        <label class="file">
                            <input type="file"  accept="image/*"  name="galleries[]" id="gallery_file" aria-label="File browser example" accept="image/*" multiple>
                            <span class="file-custom text-left">{{ __('Upload Image...') }}</span>
                        </label>
                        <br>
                        <span class="mt-1 text-info">{{ __('Image Size Should Be 800 x 800. or square size') }}</span>
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-body">
                    @if($languages->count() > 1)
                    <ul class="nav nav-tabs mb-3" id="descriptionTabs" role="tablist">
                        @foreach($languages as $index => $lang)
                        <li class="nav-item">
                            <a class="nav-link {{ $index === 0 || $lang->id == $defaultLang->id ? 'active' : '' }}" 
                               id="desc-lang-{{ $lang->id }}-tab" 
                               data-toggle="tab" 
                               href="#desc-lang-{{ $lang->id }}" 
                               role="tab">
                                <i class="fas fa-globe"></i> {{ $lang->language }}
                                @if($lang->is_default == 1) <small>({{ __('Default') }})</small> @endif
                            </a>
                        </li>
                        @endforeach
                    </ul>
                    @endif
                    <div class="tab-content">
                        @foreach($languages as $index => $lang)
                        <div class="tab-pane fade {{ $index === 0 || $lang->id == $defaultLang->id ? 'show active' : '' }}" 
                             id="desc-lang-{{ $lang->id }}" 
                             role="tabpanel">
                            <div class="form-group">
                                <label for="sort_details_{{ $lang->id }}">{{ __('Short Description') }} @if($lang->is_default == 1) * @endif</label>
                                <textarea name="sort_details_{{ $lang->id }}" id="sort_details_{{ $lang->id }}"
                                    class="form-control"
                                    placeholder="{{ __('Short Description') }}"
                                    >{{ old("sort_details_{$lang->id}") }}</textarea>
                            </div>

                            <div class="form-group">
                                <label for="details_{{ $lang->id }}">{{ __('Description') }} @if($lang->is_default == 1) * @endif</label>
                                <textarea name="details_{{ $lang->id }}" id="details_{{ $lang->id }}"
                                    class="form-control text-editor"
                                    rows="6"
                                    placeholder="{{ __('Enter Description') }}"
                                    >{{ old("details_{$lang->id}") }}</textarea>
                            </div>
                            @if($lang->id == $defaultLang->id)
                                <input type="hidden" name="sort_details" value="{{ old('sort_details') }}">
                                <input type="hidden" name="details" value="{{ old('details') }}">
                            @endif
                        </div>
                        @endforeach
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-body">
                    @if($languages->count() > 1)
                    <ul class="nav nav-tabs mb-3" id="tagsTabs" role="tablist">
                        @foreach($languages as $index => $lang)
                        <li class="nav-item">
                            <a class="nav-link {{ $index === 0 || $lang->id == $defaultLang->id ? 'active' : '' }}" 
                               id="tags-lang-{{ $lang->id }}-tab" 
                               data-toggle="tab" 
                               href="#tags-lang-{{ $lang->id }}" 
                               role="tab">
                                <i class="fas fa-globe"></i> {{ $lang->language }}
                                @if($lang->is_default == 1) <small>({{ __('Default') }})</small> @endif
                            </a>
                        </li>
                        @endforeach
                    </ul>
                    @endif
                    <div class="tab-content">
                        @foreach($languages as $index => $lang)
                        <div class="tab-pane fade {{ $index === 0 || $lang->id == $defaultLang->id ? 'show active' : '' }}" 
                             id="tags-lang-{{ $lang->id }}" 
                             role="tabpanel">
                            <div class="form-group mb-2">
                                <label for="tags_{{ $lang->id }}">{{ __('Product Tags') }}</label>
                                <input type="text" name="tags_{{ $lang->id }}" class="tags"
                                    id="tags_{{ $lang->id }}"
                                    placeholder="{{ __('Tags') }}"
                                    value="{{ old("tags_{$lang->id}") }}">
                            </div>
                            @if($lang->id == $defaultLang->id)
                                <input type="hidden" name="tags" value="">
                            @endif
                        </div>
                        @endforeach
                    </div>
                    <div class="form-group">
                        <label class="switch-primary">
                            <input type="checkbox" class="switch switch-bootstrap status radio-check" name="is_specification" value="1" checked>
                            <span class="switch-body"></span>
                            <span class="switch-text">{{ __('Specifications') }}</span>
                        </label>
                    </div>
                    <div id="specifications-section">
                        <div class="d-flex">

                            <div class="flex-grow-1">
                                <div class="form-group">
                                    <input type="text" class="form-control"
                                        name="specification_name[]"
                                        placeholder="{{ __('Specification Name') }}" value="">
                                    </div>
                            </div>
                            <div class="flex-grow-1">
                                <div class="form-group">
                                    <input type="text" class="form-control"
                                        name="specification_description[]"
                                        placeholder="{{ __('Specification description') }}" value="">
                                    </div>
                            </div>
                            <div class="flex-btn">
                                <button type="button" class="btn btn-success add-specification" data-text="{{ __('Specification Name') }}" data-text1="{{ __('Specification Description') }}"> <i class="fa fa-plus"></i> </button>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-body">
                    <!-- @if($languages->count() > 1)
                    <ul class="nav nav-tabs mb-3" id="metaTabs" role="tablist">
                        @foreach($languages as $index => $lang)
                        <li class="nav-item">
                            <a class="nav-link {{ $index === 0 || $lang->id == $defaultLang->id ? 'active' : '' }}" 
                               id="meta-lang-{{ $lang->id }}-tab" 
                               data-toggle="tab" 
                               href="#meta-lang-{{ $lang->id }}" 
                               role="tab">
                                <i class="fas fa-globe"></i> {{ $lang->language }}
                                @if($lang->is_default == 1) <small>({{ __('Default') }})</small> @endif
                            </a>
                        </li>
                        @endforeach
                    </ul>
                    @endif -->
                    <div class="tab-content">
                        @foreach($languages as $index => $lang)
                            <div class="tab-pane fade {{ $index === 0 || $lang->id == $defaultLang->id ? 'show active' : '' }}" 
                             id="meta-lang-{{ $lang->id }}" 
                             role="tabpanel">
                             
                            <div class="form-group">
                                <label for="meta_title_{{ $lang->id }}">{{ __('Meta Title') }}</label>
                                <input type="text" name="meta_title_{{ $lang->id }}" class="form-control"
                                    id="meta_title_{{ $lang->id }}"
                                    placeholder="{{ __('Enter Meta Title') }}"
                                    value="{{ old("meta_title_{$lang->id}") }}">
                            </div>

                            <div class="form-group">
                                <label for="meta_keywords_{{ $lang->id }}">{{ __('Meta Keywords') }}</label>
                                <input type="text" name="meta_keywords_{{ $lang->id }}" class="tags"
                                    id="meta_keywords_{{ $lang->id }}"
                                    placeholder="{{ __('Enter Meta Keywords') }}"
                                    value="{{ old("meta_keywords_{$lang->id}") }}">
                            </div>

                            <div class="form-group">
                                <label for="meta_description_{{ $lang->id }}">{{ __('Meta Description') }}</label>
                                <textarea name="meta_description_{{ $lang->id }}" id="meta_description_{{ $lang->id }}"
                                    class="form-control" rows="5"
                                    placeholder="{{ __('Enter Meta Description') }}"
                                >{{ old("meta_description_{$lang->id}") }}</textarea>
                            </div>
                            @if($lang->id == $defaultLang->id)
                                <input type="hidden" name="meta_title" value="">
                                <input type="hidden" name="meta_keywords" value="">
                                <input type="hidden" name="meta_description" value="">
                            @endif
                        </div>
                        @endforeach
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="card">
                <div class="card-body">
                    <input type="hidden" class="check_button" name="is_button" value="0">
                    <button type="submit" class="btn btn-secondary mr-2">{{ __('Save') }}</button>
                    <button type="submit" class="btn btn-info save__edit">{{ __('Save & Edit') }}</button>
                </div>
            </div>
            <div class="card">
                <div class="card-body">
                    <div class="form-group">
                        <label for="discount_price">{{ __('Current Price') }}
                            *</label>
                        <div class="input-group mb-3">
                            <div class="input-group-prepend">
                                <span
                                    class="input-group-text">{{ PriceHelper::adminCurrency() }}</span>
                            </div>
                            <input type="text" id="discount_price"
                                name="discount_price" class="form-control"
                                placeholder="{{ __('Enter Current Price') }}"
                                min="1" step="0.1"
                                value="{{ old('discount_price') }}" >
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="previous_price">{{ __('Previous Price') }}
                            </label>
                        <div class="input-group mb-3">
                            <div class="input-group-prepend">
                                <span
                                    class="input-group-text">{{ $curr->sign }}</span>
                            </div>
                            <input type="text" id="previous_price"
                                name="previous_price" class="form-control"
                                placeholder="{{ __('Enter Previous Price') }}"
                                min="1" step="0.1"
                                value="{{ old('previous_price') }}" >
                        </div>
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-body">

                    <div class="form-group">
                        <label for="category_id">{{ __('Select Category') }} *</label>
                        <select name="category_id" id="category_id" data-href="{{route('back.get.subcategory')}}" class="form-control" >
                            <option value="" selected>{{__('Select One')}}</option>
                            @foreach(DB::table('categories')->whereStatus(1)->get() as $cat)
                            <option value="{{ $cat->id }}">{{ $cat->name }}</option>
                            @endforeach
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="subcategory_id">{{ __('Select Sub Category') }} </label>
                        <select name="subcategory_id" id="subcategory_id" data-href="{{route('back.get.childcategory')}}" class="form-control">
                            <option value="">{{__('Select One')}}</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="childcategory_id">{{ __('Select Child Category') }} </label>
                        <select name="childcategory_id" id="childcategory_id" class="form-control">
                            <option value="">{{__('Select One')}}</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="brand_id">{{ __('Select Brand') }} </label>
                        <select name="brand_id" id="brand_id" class="form-control" >
                            <option value="" selected>{{__('Select Brand')}}</option>
                            @foreach(DB::table('brands')->whereStatus(1)->get() as $brand)
                            <option value="{{ $brand->id }}">{{ $brand->name }}</option>
                            @endforeach
                        </select>
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-body">
                    <div class="form-group">
                        <label for="stock">{{ __('Total in stock') }}
                            *</label>
                        <div class="input-group mb-3">
                            <input type="number" id="stock"
                                name="stock" class="form-control"
                                placeholder="{{ __('Total in stock') }}" value="{{ old('stock') }}" >
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="tax_id">{{ __('Select Tax') }} *</label>
                        <select name="tax_id" id="tax_id" class="form-control">
                            <option value="">{{__('Select One')}}</option>
                            @foreach(DB::table('taxes')->whereStatus(1)->get() as $tax)
                            <option value="{{ $tax->id }}">{{ $tax->name }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="sku">{{ __('SKU') }} *</label>
                        <input type="text" name="sku" class="form-control"
                            id="sku" placeholder="{{ __('Enter SKU') }}"
                            value="{{Str::random(10)}}" >
                    </div>
                    <div class="form-group">
                        <label for="video">{{ __('Video Link') }} </label>
                        <input type="text" name="video" class="form-control"
                            id="video" placeholder="{{ __('Enter Video Link') }}"
                            value="{{ old('video') }}">
                    </div>
                </div>
            </div>
        </div>

    </div>
</form>


</div>

</div>

@endsection

@push('scripts')
<script>
$(document).ready(function() {
    // Copy default language values to hidden fields
    $('.slug-source').on('input', function() {
        var value = $(this).val();
        $('input[name="name"]').val(value);
    });
    
    $('.slug-input').on('input', function() {
        var value = $(this).val();
        if ($(this).closest('.tab-pane').hasClass('active')) {
            $('input[name="slug"]').val(value);
        }
    });
});
</script>
@endpush
