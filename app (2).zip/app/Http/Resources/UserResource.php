<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class UserResource extends JsonResource
{
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'first_name' => $this->first_name,
            'last_name' => $this->last_name,
            'email' => $this->email,
            'phone' => $this->phone,
            'photo' => $this->photo ? asset('assets/images/' . $this->photo) : null,
            'display_name' => $this->displayName(),
            'email_verified' => (bool) $this->email_verify,
        ];
    }
}
